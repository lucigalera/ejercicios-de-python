def par_impar():
    numero = int(input("Ingresa un número: "))  # recibe un número
    if numero % 2 == 0:
        print("Es par")
        return "Es par"
    else:
        print("Es impar")
        return "Es impar"