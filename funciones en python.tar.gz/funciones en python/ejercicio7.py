def menu():
    print("=== MENÚ DE OPCIONES ===")
    print("1. Saludar")
    print("2. Mostrar fecha")
    print("3. Salir")

    opcion = input("Elige una opción (1-3): ")

    if opcion == "1":
        print("¡Hola! Espero que tengas un excelente día 😄")
    elif opcion == "2":
        from datetime import datetime
        print("La fecha y hora actual es:", datetime.now())
    elif opcion == "3":
        print("Saliendo del programa...")
    else:
        print("Opción no válida.")