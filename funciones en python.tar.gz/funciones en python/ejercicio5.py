def mostrar_numeros_while():
    i = 1
    while i <= 20:
        print(i)
        i += 2  # va sumando de dos en dos


