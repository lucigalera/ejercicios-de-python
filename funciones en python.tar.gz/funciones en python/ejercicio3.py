def mayor():
    a = int(input("Ingresa el primer número: "))
    b = int(input("Ingresa el segundo número: "))

    if a > b:
        print("El mayor es:", a)
        return a
    elif b > a:
        print("El mayor es:", b)
        return b
    else:
        print("Ambos son iguales:", a)
        return a 