def doble():
    numero = int(input("Ingresa un número entero: "))  # pide el parámetro
    resultado = numero * 2  # calcula el doble
    print("El doble de", numero, "es:", resultado)  # muestra el resultado
    return resultado  # retorna el valor


