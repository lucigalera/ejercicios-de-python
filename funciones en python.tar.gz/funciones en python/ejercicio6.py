def area_rectangulo(base, altura):
    resultado = base * altura
    return resultado

# Probar la función
print("El área del rectángulo es:", area_rectangulo(5, 3))
