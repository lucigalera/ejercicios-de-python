# Ingresar nombre y nota de 3 estudiantes
notas = []
for i in range(3):
    nombre = input(f"Ingrese el nombre del estudiante {i+1}: ")
    nota = float(input(f"Ingrese la nota de {nombre}: "))
    notas.append(nota)

# Calcular promedio general
promedio = sum(notas) / len(notas)
print("El promedio general de las notas es:", promedio)
