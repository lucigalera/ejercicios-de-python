# Crear un diccionario con datos de un alumno
alumno = {
    "nombre": "Lucía",
    "edad": 16,
    "curso": "4to Año",
    "nota": 8.5
}

# Imprimir sus valores
print("Datos del alumno:")
for clave, valor in alumno.items():
    print(clave, ":", valor)
