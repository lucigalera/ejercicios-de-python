# Registrar productos
producto1 = {
    "nombre": "Lapicera",
    "precio": 50,
    "stock": 120
}

producto2 = {
    "nombre": "Cuaderno",
    "precio": 200,
    "stock": 80
}

# Comparar stock
if producto1["stock"] > producto2["stock"]:
    print("El producto con más stock es:", producto1["nombre"])
elif producto2["stock"] > producto1["stock"]:
    print("El producto con más stock es:", producto2["nombre"])
else:
    print("Ambos productos tienen el mismo stock.")
