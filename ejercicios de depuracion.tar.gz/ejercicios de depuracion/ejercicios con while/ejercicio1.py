suma = 0
numero = 1
while suma < 100:
   suma += numero
   numero += 1
print("La suma total alcanzó o superó 100:", suma)
