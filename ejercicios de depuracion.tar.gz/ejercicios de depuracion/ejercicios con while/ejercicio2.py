numero_secreto = 7
adivinanza = 0
while adivinanza != numero_secreto:
   adivinanza = int(input("Adivina el número secreto: "))
   if adivinanza != numero_secreto:
       print("Incorrecto, intenta nuevamente.")
print("¡Felicidades! Adivinaste el número.")
