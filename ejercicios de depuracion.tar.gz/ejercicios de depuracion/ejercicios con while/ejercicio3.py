contador = 10
while contador > 0:
   print(contador)
   contador -= 1
print("¡Feliz Año Nuevo!")
