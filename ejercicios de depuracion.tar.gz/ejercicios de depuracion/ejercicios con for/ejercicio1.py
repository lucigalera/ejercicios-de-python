numeros = [2, 5, 8, 3, 10]
suma = 0
for num in numeros:
   suma += num
print("La suma de los elementos de la lista es:", suma)
