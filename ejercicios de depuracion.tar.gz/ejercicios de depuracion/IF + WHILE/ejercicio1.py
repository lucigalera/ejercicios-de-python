numero = 0
while numero < 1 or numero > 10:
   numero = int(input("Ingresa un número entre 1 y 10: "))
   if numero < 1 or numero > 10:
       print("Número inválido, intenta nuevamente.")
print("¡Número válido ingresado:", numero, "!")
