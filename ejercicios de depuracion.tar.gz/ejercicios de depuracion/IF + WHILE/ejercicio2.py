suma = 0
while suma <= 50:
   numero = int(input("Ingresa un número: "))
   suma += numero
   if suma <= 50:
       print("Suma actual:", suma, "- Sigue sumando...")
print("¡La suma total es mayor a 50! Suma final:", suma)
