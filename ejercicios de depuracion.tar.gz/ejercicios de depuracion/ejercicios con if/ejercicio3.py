calificacion = float(input("Ingresa tu calificación (0-10): "))
if calificacion >= 9:
   print("Excelente")
elif calificacion >= 7:
   print("Buena")
elif calificacion >= 5:
   print("Regular")
else:
   print("Insuficiente")
