numero = int(input("Ingresa un número para saber si es par o impar: "))
if numero % 2 == 0:
   print("El número es par")
else:
   print("El número es impar")
