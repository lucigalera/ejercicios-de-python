numeros = list(range(1, 11))
contador_pares = 0
for num in numeros:
   if num % 2 == 0:
       contador_pares += 1
print("Cantidad de números pares:", contador_pares)
