numeros = [5, -3, 8, -1, 0, 7, -6]
for num in numeros:
   if num > 0:
       print("Número positivo:", num)
